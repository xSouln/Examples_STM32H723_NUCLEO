//==============================================================================
//header:

#ifndef _TCP_CLIENT_WIZ_SPI_DEPENDENCIES_H
#define _TCP_CLIENT_WIZ_SPI_DEPENDENCIES_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//defines:

#define TCP_CLIENT_WIZ_SPI_COMPONENT_ENABLE 1
#define TCP_CLIENT_WIZ_SPI_ADAPTER_ENABLE 1
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_TCP_CLIENT_WIZ_SPI_DEPENDENCIES_H
