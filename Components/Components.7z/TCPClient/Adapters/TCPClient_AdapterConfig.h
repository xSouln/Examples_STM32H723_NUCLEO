//==============================================================================
//header:

#ifndef _TCP_CLIENT_ADAPTER_CONFIG_H
#define _TCP_CLIENT_ADAPTER_CONFIG_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//includes:

#include "TCPClient/TCPClient_ComponentConfig.h"
//==============================================================================
//defines:

//#define TCP_CLIENT_LWIP_ADAPTER_ENABLE 1
//#define TCP_CLIENT_WIZ_SPI_ADAPTER_ENABLE 1
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_TCP_CLIENT_ADAPTER_CONFIG_H
