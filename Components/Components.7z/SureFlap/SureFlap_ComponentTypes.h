//==============================================================================
//module enable:

#include "SureFlap_ComponentConfig.h"
#ifdef SUREFLAP_COMPONENT_ENABLE
//==============================================================================
//header:

#ifndef _SUREFLAP_COMPONENT_TYPES_H
#define _SUREFLAP_COMPONENT_TYPES_H
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//includes:

#include "Components_Types.h"
//==============================================================================
//defines:


//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_SUREFLAP_COMPONENT_TYPES_H
#endif //SUREFLAP_COMPONENT_ENABLE
