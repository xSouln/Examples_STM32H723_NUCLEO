//==============================================================================
//header:

#ifndef _SUREFLAP_ZIGBEE_ADAPTER_CONFIG_H
#define _SUREFLAP_ZIGBEE_ADAPTER_CONFIG_H
//------------------------------------------------------------------------------
#include "SureFlap/SureFlap_ComponentConfig.h"
#ifdef SUREFLAP_COMPONENT_ENABLE
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
//==============================================================================
//includes:

//==============================================================================
//defines:

//#define Zigbee_UART_ADAPTER_ENABLE 1
//==============================================================================
#ifdef __cplusplus
}
#endif
//------------------------------------------------------------------------------
#endif //_SUREFLAP_ZIGBEE_ADAPTER_CONFIG_H
#endif //SUREFLAP_COMPONENT_ENABLE
